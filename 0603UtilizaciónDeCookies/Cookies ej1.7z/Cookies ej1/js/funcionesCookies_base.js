//Función que permite crear, modificar y eliminar cookies
//Crear: dar un nombre (name) y valor (value)
//Modificar: da un nombre (name) que ya existe y un nuevo valor (value)
//Crear y modificar se pueden indicar la vigencia de la cookie en días (days)
//Si no se introduce days -->   cookie de sesión
//Eliminar: days=-1

function manageCookies(name, value, days = "") {
}

//Devuelve el valor de una cookie pasada como parámetro
//Devuelve null si no existe
function reaCookies(name) {
}

//Elimina todas las cookies del directorio que contiene la página
//Utiliza la función manageCookie
function deAllCookies() {

}
